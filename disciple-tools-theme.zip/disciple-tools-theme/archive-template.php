<?php
declare(strict_types=1);

dt_please_log_in();

if ( ! current_user_can( 'access_disciple_tools' ) ) {
    wp_safe_redirect( '/registered' );
    exit();
}

( function () {
    $post_type = dt_get_post_type();
    if ( !current_user_can( 'access_' . $post_type ) ) {
        wp_safe_redirect( '/settings' );
        exit();
    }
    $post_settings = DT_Posts::get_post_settings( $post_type );

    $field_options = $post_settings['fields'];

    $field_params = [
        'connection' => [
            'allow_add' => false,
        ],
        'key_select' => [
            'disable_color' => true,
        ]
    ];

    get_header();
    $fields_to_search = [];
    $all_searchable_fields = $post_settings['fields'];
    $all_searchable_fields['comment'] = [ 'name' => __( 'Comments', 'disciple_tools' ), 'type' => 'text' ];
    if ( isset( $_COOKIE['fields_to_search'] ) ) {
        $fields_to_search = json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['fields_to_search'] ) ) ) );
        if ( $fields_to_search ){
            $fields_to_search = dt_recursive_sanitize_array( $fields_to_search );
        }
    }
    //order fields alphabetically by Name
    uasort( $all_searchable_fields, function ( $a, $b ){
        return $a['name'] <=> $b['name'];
    });
    ?>
    <div data-sticky-container class="hide-for-small-only" style="z-index: 9">
        <nav role="navigation"
             data-sticky data-options="marginTop:0;" data-top-anchor="1"
             class="second-bar list-actions-bar">
            <div class="container-width buttons-row" ><!--  /* DESKTOP VIEW BUTTON AREA */ -->
                <a class="button dt-green create-post-desktop" href="<?php echo esc_url( home_url( '/' ) . $post_type ) . '/new' ?>">
                    <img class="dt-white-icon" style="display: inline-block;" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/circle-add.svg' ) ?>"/>
                    <span class="hide-for-small-only"><?php echo esc_html( sprintf( _x( 'Create New %s', 'Create New record', 'disciple_tools' ), $post_settings['label_singular'] ?? $post_type ) ) ?></span>
                </a>
                <a class="button filter-posts-desktop" data-open="filter-modal">
                    <img class="dt-white-icon" style="display: inline-block;" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/filter.svg?v=2' ) ?>"/>
                    <span class="hide-for-small-only"><?php esc_html_e( 'Filters', 'disciple_tools' ) ?></span>
                </a>
                <?php do_action( 'archive_template_action_bar_buttons', $post_type ) ?>
                <div class="search-wrapper">
                    <span class="text-input-wrapper">
                        <input class="search-input search-input--desktop" style="margin-right: 0;"
                               type="text" id="search-query" name="search"
                               placeholder="<?php echo esc_html( sprintf( _x( 'Search %s', "Search 'something'", 'disciple_tools' ), $post_settings['label_plural'] ?? $post_type ) ) ?>">
                        <div class="search-input__clear-button" title="<?php echo esc_html( __( 'Clear', 'disciple_tools' ) ) ?>">
                            <span>&times;</span>
                        </div>
                    </span>
                    <a class="search-addon advanced_search" id="advanced_search" title="<?php esc_html_e( 'Advanced Search', 'disciple_tools' ) ?>">
                        <img class="dt-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/options.svg' ) ?>" alt="<?php esc_html_e( 'Advanced Search', 'disciple_tools' ) ?>" />
                        <span class="badge alert advancedSearch-count" style="<?php if ( !$fields_to_search ) { echo esc_html( 'display:none' ); } ?>"><?php if ( $fields_to_search ){ echo count( $fields_to_search ); } ?></span>
                    </a>
                </div>
                <a class="button" id="search">
                    <img class="dt-white-icon" style="display: inline-block;" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/search.svg' ) ?>"/>
                    <span><?php esc_html_e( 'Search', 'disciple_tools' ) ?></span>
                </a>
                <?php if ( class_exists( 'DT_Mapbox_API' ) && DT_Mapbox_API::get_key() ) : ?>
                    <button class="button export_map_list no-margin icon-button" style="font-size:large;padding: 0.1rem 0.75rem">
                        <i class="fi-map"></i>
                    </button>
                <?php endif; ?>
            </div>
            <div id="advanced_search_picker"  class="list_field_picker" style="display:none; padding:20px; border-radius:5px; background-color:#ecf5fc;">
                <p style="font-weight:bold"><?php esc_html_e( 'Choose which fields to search', 'disciple_tools' ); ?></p>
                <ul class="ul-no-bullets" style="">

                <li style="" class="">
                    <label style="margin-right:15px; cursor:pointer">
                        <input type="checkbox" value="all"
                                <?php echo esc_html( in_array( 'all', $fields_to_search ) ? 'checked' : '' ); ?>

                                style="margin:0">
                        <b><?php esc_html_e( 'Search All Fields', 'disciple_tools' ) ?></b>
                    </label>
                </li>

                <li style="" class="">
                    <label style="margin-right:15px; cursor:pointer">
                        <input type="checkbox" value="comms"
                            <?php echo esc_html( in_array( 'comms', $fields_to_search ) ? 'checked' : '' ); ?>

                               style="margin:0">
                        <?php esc_html_e( 'Communication Channels', 'disciple_tools' ) ?>
                    </label>
                </li>

                <?php foreach ( $all_searchable_fields as $field_key => $field_values ):
                    if ( !empty( $field_values['hidden'] ) || $field_values['type'] !== 'text' ){
                        continue;
                    }
                    ?>
                    <li style="" class="">
                        <label style="margin-right:15px; cursor:pointer">
                            <input type="checkbox" value="<?php echo esc_html( $field_key ); ?>"
                                    <?php echo esc_html( in_array( $field_key, $fields_to_search ) ? 'checked' : '' );
                                    ?>
                                    style="margin:0">
                                    <?php echo esc_html( $field_values['name'] ); ?>
                        </label>
                    </li>
                <?php endforeach; ?>
                </ul>
                <button class="button" id="save_advanced_search_choices" style="display: inline-block"><?php esc_html_e( 'Apply', 'disciple_tools' ); ?></button>
                <a class="button clear" id="advanced_search_reset" style="display: inline-block"><?php esc_html_e( 'reset to default', 'disciple_tools' ); ?></a>
            </div>
        </nav>
    </div>
    <nav role="navigation" style="width:100%;"
          class="second-bar show-for-small-only center list-actions-bar"><!--  /* MOBILE VIEW BUTTON AREA */ -->
        <div class="buttons-row">
            <div class="search-wrapper">
                <span class="text-input-wrapper">
                    <input class="search-input search-input--mobile"
                           type="text" id="search-query-mobile" name="search"
                           placeholder="<?php echo esc_html( sprintf( _x( 'Search %s', "Search 'something'", 'disciple_tools' ), $post_settings['label_plural'] ?? $post_type ) ) ?>">
                    <div class="search-input__clear-button" title="<?php echo esc_html( __( 'Clear', 'disciple_tools' ) ) ?>">
                        <span>&times;</span>
                    </div>
                </span>
                <a class="search-addon advanced_search" id="advanced_search_mobile" title="<?php esc_html_e( 'Advanced Search', 'disciple_tools' ) ?>">
                    <img class="dt-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/options.svg' ) ?>" alt="<?php esc_html_e( 'Advanced Search', 'disciple_tools' ) ?>" />
                    <span class="badge alert advancedSearch-count" style="<?php if ( !$fields_to_search ) { echo esc_html( 'display:none' ); } ?>"><?php if ( $fields_to_search ){ echo count( $fields_to_search ); } ?></span>
                </a>
                <button class="search-addon" id="search-mobile">
                    <img class="dt-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/search.svg' ) ?>"/>
                </button>
            </div>
            <button class="button filter-posts-mobile" onclick="document.getElementById('tile-filters').classList.toggle('collapsed')">
                <img class="dt-white-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/filter.svg?v=2' ) ?>"/>
            </button>
            <?php do_action( 'archive_template_mobile_action_bar_buttons', $post_type ) ?>

            <?php if ( class_exists( 'DT_Mapbox_API' ) && DT_Mapbox_API::get_key() ) : ?>
                <button class="button export_map_list no-margin icon-button">
                    <i class="fi-map"></i>
                </button>
            <?php endif; ?>
        </div>
        <div id="advanced_search_picker_mobile"  class="list_field_picker" style="display:none; padding:20px; border-radius:5px; background-color:#ecf5fc;">
                <p style="font-weight:bold"><?php esc_html_e( 'Choose which fields to search', 'disciple_tools' ); ?></p>
                <ul class="ul-no-bullets" style="">

                <li style="" class="">
                    <label style="margin-right:15px; cursor:pointer">
                        <input type="checkbox" value="all"
                                <?php echo esc_html( in_array( 'all', $fields_to_search ) ? 'checked' : '' ); ?>

                                style="margin:0">
                                <b><?php esc_html_e( 'Search All Fields', 'disciple_tools' ) ?></b>
                    </label>
                </li>

                <li style="" class="">
                    <label style="margin-right:15px; cursor:pointer">
                        <input type="checkbox" value="comms"
                            <?php echo esc_html( in_array( 'comms', $fields_to_search ) ? 'checked' : '' ); ?>

                               style="margin:0">
                        <?php esc_html_e( 'Communication Channels', 'disciple_tools' ) ?>
                    </label>
                </li>

                <?php foreach ( $all_searchable_fields as $field_key => $field_values ):
                    if ( !empty( $field_values['hidden'] ) || $field_values['type'] !== 'text' ){
                        continue;
                    }
                    ?>
                    <li style="" class="">
                        <label style="margin-right:15px; cursor:pointer">
                            <input type="checkbox" value="<?php echo esc_html( $field_key ); ?>"
                                    <?php echo esc_html( in_array( $field_key, $fields_to_search ) ? 'checked' : '' );
                                    ?>
                                    style="margin:0">
                            <?php echo esc_html( $field_values['name'] ); ?>
                        </label>
                    </li>
                <?php endforeach; ?>
                </ul>
                <button class="button" id="save_advanced_search_choices_mobile" style="display: inline-block"><?php esc_html_e( 'Apply', 'disciple_tools' ); ?></button>
                <a class="button clear" id="advanced_search_reset_mobile" style="display: inline-block"><?php esc_html_e( 'reset to default', 'disciple_tools' ); ?></a>
            </div>
    </nav>
    <div id="content" class="archive-template">
        <div id="inner-content">
            <aside class="" id="list-filters">
                <div class="bordered-box collapsed" id="tile-filters">
                    <div class="section-header">
                        <?php echo esc_html( sprintf( _x( '%s Filters', 'Contacts Filters', 'disciple_tools' ), DT_Posts::get_post_settings( $post_type )['label_plural'] ) ) ?>
                        <button class="section-chevron chevron_down">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_down.svg' ) ?>"/>
                        </button>
                        <button class="section-chevron chevron_up">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_up.svg' ) ?>"/>
                        </button>
                    </div>
                    <div class="section-body">
                        <ul class="accordion" id="list-filter-tabs" data-responsive-accordion-tabs="accordion medium-tabs large-accordion"></ul>
                        <div style="margin-bottom: 5px">
                            <a data-open="filter-modal"><img class="dt-blue-icon dt-icon" style="display: inline-block; margin-right:12px" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/circle-add.svg' ) ?>"/><?php esc_html_e( 'Create custom filter', 'disciple_tools' ) ?></a>
                        </div>
                        <div class="custom-filters"></div>
                    </div>
                </div>
                <div class="bordered-box collapsed" id="tile-list-exports">
                    <div class="section-header">
                        <?php echo esc_html( _x( 'List Exports', 'List Exports', 'disciple_tools' ) ) ?>
                        <button class="float-right" data-open="export_help_text">
                            <img class="help-icon"  style="padding-left: 5px;" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/help.svg' ) ?>" alt="help"/>
                        </button>
                        <button class="section-chevron chevron_down">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_down.svg' ) ?>"/>
                        </button>
                        <button class="section-chevron chevron_up">
                            <img src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/chevron_up.svg' ) ?>"/>
                        </button>
                    </div>
                    <div class="section-body" style="padding-top:1em;">
                        <a id="export_csv_list"><?php esc_html_e( 'CSV List', 'disciple_tools' ) ?></a>
                        <?php
                        if ( !empty( DT_Posts::get_field_settings_by_type( $post_type, 'communication_channel' ) ) ) {
                            ?>
                            <a id="export_bcc_email_list"><?php esc_html_e( 'BCC Email List', 'disciple_tools' ) ?></a>
                            <a id="export_phone_list"><?php esc_html_e( 'Phone List', 'disciple_tools' ) ?></a>
                            <?php
                        }
                        if ( class_exists( 'DT_Mapbox_API' ) && DT_Mapbox_API::get_key() ) {
                            ?>
                            <a class="export_map_list"><?php esc_html_e( 'Map List', 'disciple_tools' ) ?></a>
                            <?php
                        }
                        ?>
                        <?php do_action( 'dt_list_exports_menu_items', $post_type ); ?>

                    </div>
                </div>
                <div id="export_help_text" class="large reveal" style="display: none;" data-reveal data-v-offset="10px">
                    <span class="section-header"><?php esc_html_e( 'List Exports Help', 'disciple_tools' ) ?></span>
                    <hr>
                    <div class="grid-x">
                        <div class="cell">
                            <p><strong><?php esc_html_e( 'CSV List', 'disciple_tools' ); ?></strong></p>
                            <p><?php esc_html_e( 'Using the current filter, this is a simple way to export basic information and use it in other applications.', 'disciple_tools' ); ?></p>
                        </div>
                        <div class="cell">
                            <p><strong><?php esc_html_e( 'BCC Email List', 'disciple_tools' ); ?></strong></p>
                            <p><?php esc_html_e( 'Using the current filter, the available emails are grouped by 50 and can be launched into your default email client by group. Many email providers put a limit of 50 on BCC emails. You can open all groups at once using the "Open All" button. If the list is too large, this might alert your email provider. The BCC email tool is meant to assist small group emails. Bulk email should be handled through bulk email providers.', 'disciple_tools' ); ?></p>
                        </div>
                        <div class="cell">
                            <p><strong><?php esc_html_e( 'Phone Number List', 'disciple_tools' ); ?></strong></p>
                            <p><?php esc_html_e( 'Using the current filter, this is intended for copy pasting a list of numbers into a messaging app, WhatsApp, Signal, etc. This is a quick way of starting a group conversation.', 'disciple_tools' ); ?></p>
                        </div>
                        <div class="cell">
                            <p><strong><?php esc_html_e( 'Map List', 'disciple_tools' ); ?></strong></p>
                            <p><?php esc_html_e( 'Using the current filter, this creates a basic points map of known locations of listed individuals.', 'disciple_tools' ); ?></p>
                        </div>
                        <?php
                        $list_exports_help = apply_filters( 'dt_post_list_exports_filters_sidebar_help_text', [] );
                        foreach ( $list_exports_help as $help ) {
                            ?>
                            <div class="cell">
                                <p><strong><?php echo esc_attr( $help['title'] ); ?></strong></p>
                                <p><?php echo esc_attr( $help['text'] ); ?></p>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                    <button class="close-button" data-close aria-label="Close modal" type="button">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <template id="template-split-by-filter">
                    <div class="field-select-wrapper">
                        <select id="split_by_current_filter_select" style="margin-bottom: 0">
                            <option value="" disabled selected><?php echo esc_html( _x( 'select split by field', 'disciple_tools' ) ) ?></option>
                            <?php
                            $split_by_fields = [];
                            foreach ( DT_Posts::get_post_settings( $post_type )['fields'] ?? [] as $key => $field ){
                                if ( in_array( $field['type'], [ 'multi_select', 'key_select', 'tags', 'user_select', 'location', 'boolean', 'connection' ] ) ){
                                    if ( !isset( $field['private'] ) || !$field['private'] ){
                                        $split_by_fields[$key] = $field;
                                    }
                                }
                            }

                            // Sort identified list of split by fields;
                            uasort( $split_by_fields, function ( $a, $b ){
                                if ( $a['name'] == $b['name'] ){
                                    return 0;
                                }
                                return ( $a['name'] < $b['name'] ) ? -1 : 1;
                            } );

                            // Display split by fields.
                            foreach ( $split_by_fields as $split_by_field_key => $split_by_field ){
                                ?>
                                <option
                                    value="<?php echo esc_attr( $split_by_field_key ) ?>"><?php echo esc_attr( sprintf( _x( '%1$s - (%2$s)', 'disciple_tools' ), $split_by_field['name'], $split_by_field_key ) ) ?></option>
                                <?php
                            }
                            ?>
                        </select>

                        <button id="split_by_current_filter_button" class="button loader" style='margin-bottom: 0'><?php echo esc_html( _x( 'Go', 'disciple_tools' ) ) ?></button>
                    </div>
                    <ul class="accordion split-by-current-filter-accordion"
                        data-responsive-accordion-tabs="accordion medium-tabs large-accordion"
                        style="display: none;">
                        <li class="accordion-item is-active" data-accordion-item data-id="split_by">
                            <a href="#" class="accordion-title" data-id="split_by">
                                <?php echo esc_attr( _x( 'Summary', 'disciple_tools' ) ) ?>
                            </a>
                            <div class="accordion-content" data-tab-content>
                                <div id="split_by_current_filter_results" class="list-views"></div>
                            </div>
                        </li>
                    </ul>
                    <span id="split_by_current_filter_no_results_msg" style="display: none;margin-inline-start: 10px"><?php echo esc_attr( __( 'No results found', 'disciple_tools' ) ) ?></span>
                </template>
                <?php do_action( 'dt_post_list_filters_sidebar', $post_type ) ?>
            </aside>

            <main id="main" class="" role="main">
                <div class="bordered-box">
                    <div class="list-header">
                        <span class="section-header posts-header">
                            <?php echo esc_html( sprintf( _x( '%s List', 'Contacts List', 'disciple_tools' ), DT_Posts::get_post_settings( $post_type )['label_plural'] ) ) ?>
                        </span>
                        <div id="list-loading">
                            <span id="list-loading-spinner" class="loading-spinner active"></span>
                        </div>
                        <span class="filter-result-text"></span>
                        <div id="sort-menu" class="js-sort-dropdown">
                            <ul class="dropdown menu" data-dropdown-menu>
                                <li>
                                    <a href="#"><span class="menu-label"><?php esc_html_e( 'Sort', 'disciple_tools' ); ?></span><i class="mdi mdi-sort"></i></a>
                                    <ul class="menu is-dropdown-submenu" style="min-width:220px">
                                        <li>
                                            <a href="#" class="js-sort-by" data-column-index="6" data-order="desc" data-field="post_date">
                                            <i class="mdi mdi-sort-calendar-descending"></i>
                                            <?php esc_html_e( 'Newest', 'disciple_tools' ); ?></a>
                                        </li>
                                        <li>
                                            <a href="#" class="js-sort-by" data-column-index="6" data-order="asc" data-field="post_date">
                                            <i class="mdi mdi-sort-calendar-ascending"></i>
                                            <?php esc_html_e( 'Oldest', 'disciple_tools' ); ?></a>
                                        </li>
                                        <li>
                                            <a href="#" class="js-sort-by" data-column-index="6" data-order="desc" data-field="last_modified">
                                            <i class="mdi mdi-sort-clock-descending-outline"></i>
                                            <?php esc_html_e( 'Most recently modified', 'disciple_tools' ); ?></a>
                                        </li>
                                        <li>
                                            <a href="#" class="js-sort-by" data-column-index="6" data-order="asc" data-field="last_modified">
                                            <i class="mdi mdi-sort-clock-ascending-outline"></i>
                                            <?php esc_html_e( 'Least recently modified', 'disciple_tools' ); ?></a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <?php
                        $dropdown_items = [
                            'options' =>
                                [
                                    'label' => __( 'Fields', 'disciple_tools' ),
                                    'icon' => get_template_directory_uri() . '/dt-assets/images/options.svg',
                                    'section_id' => 'list_column_picker',
                                    'show_list_checkboxes' => false,
                                ],
                            'bulk-edit' =>
                                [
                                    'label' => __( 'Bulk Edit', 'disciple_tools' ),
                                    'icon' => get_template_directory_uri() . '/dt-assets/images/bulk-edit.svg',
                                    'section_id' => 'bulk_edit_picker',
                                    'show_list_checkboxes' => true,
                                ],
                            'bulk-msg' =>
                                [
                                    'label' => __( 'Bulk Send Message', 'disciple_tools' ),
                                    'icon' => get_template_directory_uri() . '/dt-assets/images/send.svg',
                                    'section_id' => 'bulk_send_msg_picker',
                                    'show_list_checkboxes' => true,
                                    'valid_post_type' => function ( $current_post_type ) {
                                        $post_type_valid = false;

                                        // Specify list of valid communication channel fields to search for.
                                        $valid_comm_fields = [
                                            'contact_email',
                                            'contact_phone'
                                        ];

                                        // For given post type, fetch associated communication channel fields.
                                        $comm_fields = DT_Posts::get_field_settings_by_type( $current_post_type, 'communication_channel' );

                                        // Attempt to validate listed communication channel fields.
                                        foreach ( $valid_comm_fields as $valid_comm_field ) {
                                            if ( in_array( $valid_comm_field, $comm_fields ) ) {
                                                $post_type_valid = true;
                                            }
                                        }

                                        return $post_type_valid;
                                    }
                                ]
                        ];

                        // Add custom menu items
                        $dropdown_items = apply_filters( 'dt_list_action_menu_items', $dropdown_items, $post_type );
                        ?>
                        <div id="more-menu" class="js-sort-dropdown">
                            <ul class="dropdown menu" data-dropdown-menu>
                                <li>
                                    <a href="#"><span class="menu-label"><?php esc_html_e( 'More', 'disciple_tools' ) ?></span><i class="mdi mdi-dots-vertical"></i></a>
                                    <ul class="menu is-dropdown-submenu" id="dropdown-submenu-items-more">
                                    <?php foreach ( $dropdown_items as $key => $value ) : ?>
                                        <?php if ( isset( $key ) && ( !isset( $value['valid_post_type'] ) || $value['valid_post_type']( $post_type ) ) ) : ?>
                                            <?php $show_list_checkboxes = !empty( $value['show_list_checkboxes'] ) ? 'true' : 'false'; ?>
                                            <li>
                                                <a href="javascript:void(0);" data-modal="<?php echo esc_html( $value['section_id'] ); ?>" data-checkboxes="<?php echo esc_html( $show_list_checkboxes ); ?>" class="list-dropdown-submenu-item-link" id="submenu-more-<?php echo esc_html( $key ); ?>">
                                                    <img src="<?php echo esc_html( $value['icon'] ); ?>" class="list-dropdown-submenu-icon">
                                                    <?php echo esc_html( $value['label'] ); ?>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                    </ul>
                                </li>
                            </ul>
                        </div>

                        <?php
                        $status_key = isset( $post_settings['status_field'] ) ? $post_settings['status_field']['status_key'] : null;
                        $archived_key = isset( $post_settings['status_field'] ) ? $post_settings['status_field']['archived_key'] : null;
                        $archived_text = __( 'Archived', 'disciple_tools' );
                        if ( $status_key && $archived_key && isset( $post_settings['fields'][$status_key]['default'][$archived_key]['label'] ) ){
                            $archived_text = $post_settings['fields'][$status_key]['default'][$archived_key]['label'];
                        }
                        $archived_label = sprintf( _x( 'Show %s', 'Show archived', 'disciple_tools' ), $archived_text );
                        ?>

                        <?php if ( $status_key && $archived_key ) : ?>
                        <span id="archived-switch" class="show-closed-switch">
                            <?php echo esc_html( $archived_label ) ?>
                            <div class="switch tiny">
                                <input class="switch-input" id="archivedToggle" type="checkbox" name="archivedToggle">
                                <label class="switch-paddle" for="archivedToggle">
                                    <span class="show-for-sr"><?php echo esc_html( $archived_label ) ?></span>
                                </label>
                            </div>
                        </span>
                        <?php endif; ?>

                    </div>

                    <?php
                    $fields_to_show_in_table = [];
                    if ( isset( $_COOKIE['fields_to_show_in_table'] ) ) {
                        $fields_to_show_in_table = json_decode( stripslashes( sanitize_text_field( wp_unslash( $_COOKIE['fields_to_show_in_table'] ) ) ) );
                        if ( $fields_to_show_in_table ){
                            $fields_to_show_in_table = dt_recursive_sanitize_array( $fields_to_show_in_table );
                        }
                    }

                    // Get enabled fields (either from cookie or defaults)
                    $enabled_fields = [];
                    if ( empty( $fields_to_show_in_table ) ) {
                        // Use default fields if no cookie is set
                        foreach ( $post_settings['fields'] as $field_key => $field_values ) {
                            if ( !empty( $field_values['show_in_table'] ) && empty( $field_values['hidden'] ) ) {
                                $enabled_fields[] = $field_key;
                            }
                        }
                    } else {
                        $enabled_fields = $fields_to_show_in_table;
                    }

                    //order fields alphabetically by Name
                    uasort( $post_settings['fields'], function ( $a, $b ){
                        return $a['name'] <=> $b['name'];
                    });

                    ?>

                    <div style="display: flex; flex-wrap:wrap; margin: 10px 0" id="current-filters"></div>

                    <div class="table-container">
                        <table class="table-remove-top-border js-list stack striped" id="records-table">
                            <thead>
                                <tr class="table-headers dnd-moved sortable">
                                    <th id="bulk_edit_master" data-id="record_picture" style="width:32px; background-image:none; cursor:default; padding-right: 10px;">
                                        <input type="checkbox" name="bulk_send_app_id" value="" id="bulk_edit_master_checkbox">
                                    </th>

                                    <?php $columns = [];
                                    if ( empty( $fields_to_show_in_table ) ){
                                        $columns = DT_Posts::get_default_list_column_order( $post_type );
                                    }
                                    $columns = array_unique( array_merge( $fields_to_show_in_table, $columns ) );
                                    if ( in_array( 'favorite', $columns ) ) {
                                        ?>
                                        <th style="width:36px; background-image:none; cursor:default"></th>
                                        <?php
                                    }
                                    foreach ( $columns as $field_key ):
                                        if ( ! in_array( $field_key, [ 'favorite', 'record_picture' ] ) ):
                                            if ( isset( $post_settings['fields'][$field_key]['name'] ) ) : ?>
                                                <th class="all" data-id="<?php echo esc_html( $field_key ) ?>">
                                                    <?php echo esc_html( $post_settings['fields'][ $field_key ]['name'] ) ?>
                                                </th>
                                            <?php endif;
                                        endif;
                                    endforeach ?>
                                </tr>
                            </thead>
                            <tbody id="table-content">
                                <tr class="js-list-loading"><td colspan=7><?php esc_html_e( 'Loading...', 'disciple_tools' ); ?></td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="center">
                        <button id="load-more" class="button loader" style="display: none"><?php esc_html_e( 'Load More', 'disciple_tools' ) ?></button>
                    </div>
                </div>
            </main>

            <aside id="list-actions" class="list-actions">
                <div class="bordered-box" id="tile-filters">
                    <div class="section-header">
                        <span><?php esc_html_e( 'Actions', 'disciple_tools' ) ?></span>
                        <button class="close-button list-action-close-button" aria-label="<?php esc_html_e( 'Close', 'disciple_tools' ); ?>" type="button">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="section-body">
                        <?php
                        // Add section UI for custom menus
                        do_action( 'dt_list_action_section', $post_type, $post_settings );
                        ?>

                        <div id="list_column_picker" class="list_field_picker list_action_section">
                            <p style="font-weight:bold"><?php esc_html_e( 'Choose which fields to display as columns in the list', 'disciple_tools' ); ?></p>

                            <div class="field-selection-ui">
                                <!-- Search input for adding fields -->
                                <div style="margin-bottom: 15px;">
                                    <label for="field_search_input" class="field-search-label">
                                        <?php esc_html_e( 'Add fields:', 'disciple_tools' ); ?>
                                    </label>
                                    <div class="field-search-container">
                                        <input type="text" id="field_search_input" class="field-search-input" placeholder="<?php esc_html_e( 'Search for fields to add...', 'disciple_tools' ); ?>">
                                        <div id="field_search_dropdown" class="field-search-dropdown">
                                            <?php foreach ( $post_settings['fields'] as $field_key => $field_values ):
                                                if ( !empty( $field_values['hidden'] ) ){
                                                    continue;
                                                }
                                                $has_icon = !empty( $field_values['icon'] ) || !empty( $field_values['font-icon'] );
                                                $option_classes = 'field-search-option' . ( $has_icon ? '' : ' no-icon' );
                                                ?>
                                                <div class="<?php echo esc_attr( $option_classes ); ?> field-search-option-inline" data-field-key="<?php echo esc_attr( $field_key ); ?>"
                                                     data-field-name="<?php echo esc_attr( strtolower( $field_values['name'] ) ); ?>">
                                                    <?php dt_render_field_icon( $field_values ); ?>
                                                    <span><?php echo esc_html( $field_values['name'] ); ?></span>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Enabled fields display -->
                                <div class="enabled-fields-section">
                                    <label class="enabled-fields-label">
                                        <?php esc_html_e( 'Enabled fields:', 'disciple_tools' ); ?>
                                    </label>
                                    <div id="enabled_fields_container" class="enabled-fields-container">
                                        <?php if ( empty( $enabled_fields ) ): ?>
                                            <span class="no-fields-message"><?php esc_html_e( 'No fields selected', 'disciple_tools' ); ?></span>
                                        <?php else : ?>
                                            <?php foreach ( $enabled_fields as $field_key ): ?>
                                                <?php if ( isset( $post_settings['fields'][$field_key] ) ): ?>
                                                    <?php
                                                    $field_settings = $post_settings['fields'][$field_key];
                                                    $has_icon = !empty( $field_settings['icon'] ) || !empty( $field_settings['font-icon'] );
                                                    $tag_classes = 'enabled-field-tag' . ( $has_icon ? '' : ' no-icon' );
                                                    ?>
                                                    <span class="<?php echo esc_attr( $tag_classes ); ?> enabled-field-tag-inline" data-field-key="<?php echo esc_attr( $field_key ); ?>">
                                                    <?php dt_render_field_icon( $field_settings, 'dt-icon' ); ?>
                                                    <span><?php echo esc_html( $field_settings['name'] ); ?></span>
                                                    <button type="button" class="remove-field-btn remove-field-btn-inline" data-field-key="<?php echo esc_attr( $field_key ); ?>">×</button>
                                                </span>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Hidden input to store selected fields -->
                                <input type="hidden" id="selected_fields_input" value="<?php echo esc_attr( json_encode( $enabled_fields ) ); ?>">

                                <button class="button" id="save_column_choices" style="display: inline-block"><?php esc_html_e( 'Apply', 'disciple_tools' ); ?></button>
                                <a class="button clear" id="reset_column_choices" style="display: inline-block"><?php esc_html_e( 'reset to default', 'disciple_tools' ); ?></a>
                            </div>
                        </div>

                        <form id="bulk_edit_picker" class="list_action_section">
                            <button class="close-button list-action-close-button" data-close="bulk_edit_picker" aria-label="<?php esc_html_e( 'Close', 'disciple_tools' ); ?>" type="button">
                                <span aria-hidden="true">×</span>
                            </button>
                            <p style="font-weight:bold"><?php
                                echo sprintf( esc_html__( 'Select all the %1$s you want to update from the list, and update them below', 'disciple_tools' ), esc_html( $post_type ) );?></p>
                            <div class="grid-x">
                                <!-- Dynamic Field Selection Section -->
                                <div class="cell small-12" id="bulk_edit_dynamic_fields_section">
                                        <div class="section-subheader">
                                        <?php esc_html_e( 'Add Fields to Update', 'disciple_tools' ); ?>
                                        </div>
                                    
                                    <!-- Field Selection with dt-multi-select -->
                                    <div class="bulk-edit-field-select-wrapper" style="margin-bottom: 15px;">
                                        <dt-multi-select
                                            id="bulk_edit_field_selector"
                                            name="bulk_edit_field_selector"
                                            placeholder="<?php esc_attr_e( 'Search and add fields...', 'disciple_tools' ); ?>"
                                            options='[]'
                                            value='[]'>
                                        </dt-multi-select>
                                        </div>
                                    
                                    <!-- Selected Fields Container -->
                                    <div class="bulk-edit-selected-fields-container" id="bulk_edit_selected_fields_container">
                                        <!-- Fields will be dynamically added here -->
                                </div>

                                    <!-- Hidden input to store selected field keys -->
                                    <input type="hidden" id="bulk_edit_selected_fields_input" value="[]">
                                    
                                    <!-- Hidden data element with comment sections for dynamic comment fields -->
                                    <?php
                                        // Start with default comment section
                                        $comment_sections = [
                                            [
                                                'key' => 'comment',
                                                'label' => __( 'Comments', 'disciple_tools' ),
                                                'selected_by_default' => true,
                                                'always_show' => true,
                                            ]
                                        ];
                                        // Apply filter to get additional sections
                                        $comment_sections = apply_filters( 'dt_comments_additional_sections', $comment_sections, $post_type );
                                        ?>
                                    <script type="application/json" id="bulk_edit_comment_sections_data">
                                        <?php echo json_encode( $comment_sections ); ?>
                                    </script>
                                </div>
                            </div>

                            <!-- Instruction message (shown when no records selected) -->
                            <div id="bulk_edit_no_selection_message" class="bulk-edit-no-selection-message">
                                <strong><?php esc_html_e( 'Please select records from the displayed list, to enable bulk actions.', 'disciple_tools' ); ?></strong>
                            </div>

                            <!-- Action buttons (hidden initially) -->
                            <div id="bulk_edit_action_buttons" class="bulk-edit-action-buttons" style="display:none;">
                                <button class="button dt-green bulk-edit-update-btn" id="bulk_edit_submit">
                                    <i class="mdi mdi-update"></i>
                                    <span class="bulk_edit_submit_text" data-pretext="<?php echo esc_html__( 'Update', 'disciple_tools' ); ?>" data-posttext="<?php echo esc_html( $post_settings['label_plural'] ); ?>" style="text-transform:capitalize;">
                                        <?php echo esc_html( __( 'Make Selections Below', 'disciple_tools' ) ); ?>
                                    </span>
                                    <span id="bulk_edit_submit-spinner" style="display: inline-block;" class="loading-spinner"></span>
                                </button>
                                <?php if ( current_user_can( 'delete_any_' . $post_type ) ){ ?>
                                    <button class="button bulk-edit-delete-btn" id="bulk_edit_delete_submit">
                                        <i class="mdi mdi-delete-outline"></i>
                                    <span class="bulk_edit_delete_submit_text"
                                          data-pretext="<?php echo esc_html__( 'Delete', 'disciple_tools' ); ?>"
                                          data-posttext="<?php echo esc_html( $post_settings['label_plural'] ); ?>"
                                          style="text-transform:capitalize;">
                                        <?php echo esc_html( __( 'Delete Selections Below', 'disciple_tools' ) ); ?>
                                    </span>
                                    <span id="bulk_edit_delete_submit-spinner" style="display: inline-block;"
                                          class="loading-spinner"></span>
                                </button>
                            <?php } ?>
                            </div>
                        </form>

                        <!-- Template for rendering selected fields -->
                        <div id="bulk_edit_field_template" style="display:none;">
                            <div class="bulk-edit-field-wrapper cell small-12" data-field-key="">
                                <div class="bulk-edit-field-header">
                                    <div class="section-subheader">
                                        <span class="bulk-edit-field-icon"></span>
                                        <span class="bulk-edit-field-name"></span>
                                        <button type="button" class="bulk-edit-remove-field-btn" data-field-key="" title="<?php esc_attr_e( 'Remove field', 'disciple_tools' ); ?>">
                                            <i class="mdi mdi-close-circle-outline"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="bulk-edit-field-input-container">
                                    <!-- Field input will be rendered here -->
                                </div>
                                <div class="bulk-edit-field-actions">
                                    <dt-toggle class="bulk-edit-mode-toggle" data-field-key="" label="<?php esc_attr_e( 'Remove Values', 'disciple_tools' ); ?>" style="display:none;"></dt-toggle>
                                </div>
                            </div>
                        </div>

                        <div id="bulk_send_msg_picker" class="list_action_section">
                            <button class="close-button list-action-close-button" data-close="bulk_send_msg_picker" aria-label="<?php esc_html_e( 'Close', 'disciple_tools' ); ?>" type="button">
                                <span aria-hidden="true">×</span>
                            </button>
                            <p style="font-weight:bold"><?php
                                echo sprintf( esc_html__( 'Select all the %1$s to whom you want to message.', 'disciple_tools' ), esc_html( $post_type ) );?></p>
                            <div class="cell">
                                <?php
                                $has_twilio = class_exists( 'Disciple_Tools_Twilio_API', false ) && Disciple_Tools_Twilio_API::has_credentials() && Disciple_Tools_Twilio_API::is_enabled();
                                $dt_site_notification_defaults = dt_get_site_notification_defaults();
                                $default_subject = dt_get_option( 'dt_email_base_subject' );
                                $default_message = 'Hello {{name}},

Bulk send message...

Thanks!';

                                /**
                                 * Filter the default message for the current post type.
                                 *
                                 * @param string $default_message The default message.
                                 * @param string $post_type The post type.
                                 * @return string The filtered default message.
                                 */
                                $default_message = apply_filters( 'dt_post_messaging_message_default', $default_message, $post_type );
                                // Filter communication channels.
                                $comms_channels = [];
                                foreach ( $dt_site_notification_defaults['channels'] as $channel_key => $channel_value ){
                                    if ( $channel_key === 'web' ) {
                                        continue;
                                    }

                                    if ( !$has_twilio && $channel_key === 'sms' ) {
                                        continue;
                                    }

                                    $comms_channels[ $channel_key ] = $channel_value;
                                }
                                $msg_reply_to = dt_get_option( 'dt_email_base_address_reply_to' );
                                if ( empty( $msg_reply_to ) ) {
                                    $msg_reply_to = dt_get_option( 'dt_email_base_address' );
                                }
                                ?>
                                <label for="bulk_send_msg_subject"><?php echo esc_html__( 'Message subject', 'disciple_tools' ); ?></label>
                                <input type="text" id="bulk_send_msg_subject" value="<?php echo esc_attr( $default_subject ); ?>" style="margin-bottom: 0"/>
                                <span id="bulk_send_msg_subject_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><?php echo esc_html__( 'A valid message subject must be entered.', 'disciple_tools' ); ?></span><br>

                                <label for="bulk_send_msg_from_name"><?php echo esc_html__( 'Message from name', 'disciple_tools' ); ?></label>
                                <input type="text" id="bulk_send_msg_from_name" value="<?php echo esc_attr( dt_default_email_name() ); ?>" style="margin-bottom: 0"/>
                                <span id="bulk_send_msg_from_name_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><?php echo esc_html__( 'A valid from name must be specified.', 'disciple_tools' ); ?></span><br>

                                <label for="bulk_send_msg_reply_to"><?php echo esc_html__( 'Message reply to', 'disciple_tools' ); ?></label>
                                <input type="text" id="bulk_send_msg_reply_to" value="<?php echo esc_attr( $msg_reply_to ); ?>" style="margin-bottom: 0"/>
                                <span id="bulk_send_msg_reply_to_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><?php echo esc_html__( 'A valid reply to email address must be specified.', 'disciple_tools' ); ?></span><br>

                                <span><?php echo sprintf( esc_html__( 'Emails will be sent from: %s', 'disciple_tools' ), esc_html( dt_default_email_address() ) ); ?></span><br>

                                <!--                                --><?php
                                //                                if ( count( $comms_channels ) > 1 ) {
                                //                                    ?>
                                <!--                                    <br><label>--><?php //echo esc_html__( 'Select message send method', 'disciple_tools' ); ?><!--</label>-->
                                <!--                                    --><?php
                                //                                    foreach ( $comms_channels as $channel_key => $channel_value ) {
                                //                                        if ( !in_array( $channel_key, [ 'web' ] ) ) {
                                //                                            $method_id = 'bulk_send_msg_method_' . $channel_key;
                                //                                            ?>
                                <!--                                            <input type="radio" class="bulk-send-msg-method"-->
                                <!--                                                   id="--><?php //echo esc_attr( $method_id ); ?><!--"-->
                                <!--                                                   name="bulk_send_msg_method"-->
                                <!--                                                   value="--><?php //echo esc_attr( $channel_key ); ?><!--"-->
                                <!--                                                --><?php //echo( ( $channel_key === 'email' ) ? 'checked' : '' ) ?><!--/>-->
                                <!--                                            <label-->
                                <!--                                                for="--><?php //echo esc_attr( $method_id ); ?><!--">--><?php //echo esc_html( $channel_value['label'] ); ?><!--</label>-->
                                <!--                                            --><?php
                                //                                        }
                                //                                    }
                                //                                }
                                //                                ?>
                                <span id="bulk_send_msg_method_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><br><?php echo esc_html__( 'Please ensure a valid send method has been specified.', 'disciple_tools' ); ?></span><br>

                                <label for="bulk_send_msg"><?php echo esc_html__( 'Message', 'disciple_tools' ); ?></label>
                                <textarea type="text" id="bulk_send_msg" rows="10"><?php echo esc_textarea( $default_message ); ?></textarea>
                                <span id="bulk_send_msg_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><?php echo esc_html__( 'Please ensure a valid send message has been entered.', 'disciple_tools' ); ?></span><br>
                                <span><?php echo esc_html__( 'Message placeholders', 'disciple_tools' ); ?></span>
                                <ul>
                                    <?php

                                    /**
                                     * Filter the message placeholders for the current post type.
                                     *
                                     * @param array $message_placeholders The message placeholders.
                                     * @param string $post_type The post type.
                                     * @return array The filtered message placeholders. The array should be in the following format:
                                     * [
                                     *     [
                                     *         'name' => '{{name}}', // Required
                                     *         'description' => 'Name of the Record', // Required
                                     *         'help' => [ // Optional
                                     *             'id' => 'placeholder_help_text_1', // Required
                                     *             'title' => 'Name of the Record', // Required
                                     *             'description' => 'Description of the Record', // Required
                                     *             'items' => [ // Optional
                                     *                 [
                                     *                     'title' => 'Title of the Item',
                                     *                     'text' => 'Text of the Item',
                                     *                 ]
                                     *             ]
                                     *         ]
                                     *     ]
                                     * ]
                                     */
                                    $message_placeholders = apply_filters( 'dt_post_messaging_message_placeholders', [
                                        [
                                            'name' => '{{name}}',
                                            'description' => __( 'Name of the Record', 'disciple_tools' ),
                                        ],
                                    ], $post_type );
                                    ?>

                                    <?php foreach ( $message_placeholders as $placeholder ) : ?>

                                        <li>
                                            <span style="font-weight: bold;"><?php echo esc_html( $placeholder['name'] ); ?></span>:
                                            <?php echo esc_html( $placeholder['description'] ); ?>

                                            <?php if ( isset( $placeholder['help'] ) ) : ?>
                                                <button class="float-right" data-open="placeholder_help_text_<?php echo esc_attr( $placeholder['help']['id'] ); ?>">
                                                    <img class="help-icon"  style="padding-left: 5px;" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/help.svg' ) ?>" alt="help"/>
                                                </button>
                                            <?php endif; ?>
                                        </li>


                                        <?php if ( isset( $placeholder['help'] ) ) : ?>

                                            <div id="placeholder_help_text_<?php echo esc_attr( $placeholder['help']['id'] ); ?>" class="large reveal" style="display: none;" data-reveal data-v-offset="10px">
                                                <span class="section-header"><?php esc_html_e( 'Message Placeholder Help', 'disciple_tools' ) ?></span>
                                                <hr>
                                                <div class="grid-x">

                                                    <?php if ( isset( $placeholder['help']['title'] ) ) : ?>

                                                        <div class="cell">
                                                            <p><strong><?php echo esc_html( $placeholder['help']['title'] ); ?></strong></p>
                                                        </div>

                                                    <?php endif; ?>

                                                    <?php if ( isset( $placeholder['help']['description'] ) ) : ?>
                                                        <div class="cell">
                                                            <p><?php echo esc_html( $placeholder['help']['description'] ); ?></p>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php foreach ( $placeholder['help']['items'] as $item ) : ?>

                                                        <div class="cell">
                                                            <?php if ( isset( $item['title'] ) ) : ?>
                                                                <span><strong><?php echo esc_html( $item['title'] ); ?></strong></span>:<?php echo ' '; ?>
                                                            <?php endif; ?>
                                                            <?php if ( isset( $item['text'] ) ) : ?>
                                                                <span><?php echo esc_html( $item['text'] ); ?></span>
                                                            <?php endif; ?>
                                                        </div>

                                                    <?php endforeach; ?>

                                                </div>
                                                <button class="close-button" data-close aria-label="Close modal" type="button">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                        <?php endif; ?>

                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <div class="cell">
                                <label for="bulk_send_msg_required_elements"><?php echo esc_html__( 'Send to selected records', 'disciple_tools' ); ?></label>
                                <span id="bulk_send_msg_required_elements" style="display:none;color:red;"><?php echo esc_html__( 'You must select at least one record', 'disciple_tools' ); ?></span>
                                <div>
                                    <button class="button dt-green" id="bulk_send_msg_submit">
                                    <span class="bulk_edit_submit_text" data-pretext="<?php echo esc_html__( 'Send', 'disciple_tools' ); ?>" data-posttext="<?php echo esc_html__( 'Links', 'disciple_tools' ); ?>" style="text-transform:capitalize;">
                                        <?php echo esc_html( __( 'Make Selections Below', 'disciple_tools' ) ); ?>
                                    </span>
                                        <span id="bulk_send_msg_submit-spinner" style="display: inline-block" class="loading-spinner"></span>
                                    </button><br>
                                    <span id="bulk_send_msg_submit_support_text" style="display: none; font-style: italic; font-size: 11px; color: #ff0000;"><?php echo esc_html__( 'Ensure valid record selections have been made.', 'disciple_tools' ); ?></span>
                                </div>
                                <span id="bulk_send_msg_submit-message"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
        <a class="button dt-green create-post-mobile" href="<?php echo esc_url( home_url( '/' ) . $post_type ) . '/new' ?>">
            <img class="dt-white-icon" src="<?php echo esc_html( get_template_directory_uri() . '/dt-assets/images/add.svg' ) ?>"/>
        </a>
    </div>

    <div class="reveal" id="filter-modal" data-reveal>
        <div class="grid-container">
            <div class="grid-x">
                <div class="cell small-4" style="padding: 0 2px 5px 2px">
                    <input type="search" id="field-filter-name"
                           placeholder="<?php esc_html_e( 'Field Name', 'disciple_tools' )?>"
                           style="margin-bottom: 0"/>
                </div>
                <div class="cell small-7">
                    <div id="selected-filters"></div>
                </div>
            </div>

            <div class="grid-x">
                <div class="cell small-4 filter-modal-left">
                    <?php $fields = [];
                    $allowed_types = [ 'user_select', 'multi_select', 'key_select', 'boolean', 'date', 'datetime', 'location', 'location_meta', 'connection', 'tags', 'text', 'communication_channel', 'file_upload' ];
                    //order fields alphabetically by Name
                    uasort( $field_options, function ( $a, $b ){
                        return strnatcmp( $a['name'] ?? 'z', $b['name'] ?? 'z' );
                    });
                    foreach ( $field_options as $field_key => $field ){
                        if ( $field_key && in_array( $field['type'] ?? '', $allowed_types ) && !in_array( $field_key, $fields ) && !( isset( $field['hidden'] ) && $field['hidden'] ) ){
                            $fields[] = $field_key;
                        }
                    }
                    ?>
                    <ul class="vertical tabs" data-tabs id="filter-tabs">
                        <?php foreach ( $fields as $index => $field ) :
                            if ( isset( $field_options[$field]['name'] ) ) : ?>
                                <li class="tabs-title <?php if ( $index === 0 ){ echo 'is-active'; } ?>" data-field="<?php echo esc_html( $field )?>">
                                    <a href="#<?php echo esc_html( $field )?>" <?php if ( $index === 0 ){ echo 'aria-selected="true"'; } ?>>
                                        <?php
                                        $rendered = dt_render_field_icon( $field_options[$field], 'tabs-title__icon' );
                                        if ( !$rendered ){
                                            ?><div class="tabs-title__icon"></div><?php
                                        }
                                        echo esc_html( $field_options[$field]['name'] ) ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="cell small-8 tabs-content filter-modal-right" data-tabs-content="filter-tabs">
                    <?php foreach ( $fields as $index => $field ) :
                        $is_multi_select = isset( $field_options[$field] ) && ( in_array( $field_options[$field]['type'], [ 'multi_select', 'tags' ] ) );
                        if ( isset( $field_options[$field] ) && ( $field_options[$field]['type'] === 'connection' || $field_options[$field]['type'] === 'location' || $field_options[$field]['type'] === 'location_meta' || $field_options[$field]['type'] === 'user_select' || $is_multi_select ) ) : ?>
                            <div class="tabs-panel <?php if ( $index === 0 ){ echo 'is-active'; } ?>" id="<?php echo esc_html( $field ) ?>">
                                <div class="section-header"><?php echo esc_html( $field_options[$field]['name'] ) ?></div>
                                <div class="<?php echo esc_html( $field );?>  <?php echo esc_html( $is_multi_select ? 'multi_select' : '' ) ?> details" >
                                    <var id="<?php echo esc_html( $field ) ?>-result-container" class="result-container <?php echo esc_html( $field ) ?>-result-container"></var>
                                    <div id="<?php echo esc_html( $field ) ?>_t" name="form-<?php echo esc_html( $field ) ?>" class="scrollable-typeahead typeahead-margin-when-active">
                                        <div class="typeahead__container">
                                            <div class="typeahead__field">
                                                <span class="typeahead__query">
                                                    <input class="js-typeahead-<?php echo esc_html( $field ) ?> input-height"
                                                           data-field="<?php echo esc_html( $field )?>"
                                                           data-type="<?php echo esc_html( $field_options[$field]['type'] ) ?>"
                                                           name="<?php echo esc_html( $field ) ?>[query]"
                                                           placeholder="<?php echo esc_html_x( 'Type to search', 'input field placeholder', 'disciple_tools' ) ?>"
                                                           autocomplete="off">
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if ( $field_options[$field]['type'] === 'connection' ) : ?>
                                    <p>
                                        <label><?php echo esc_html( sprintf( _x( 'All %1$s with %2$s', 'All Contacts with Is Coaching', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            <input class="all-connections" type="checkbox" value="all-connections" />
                                        </label>
                                        <label><?php echo esc_html( sprintf( _x( 'All %1$s without %2$s', 'All Contacts without Is Coaching', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            <input class="all-without-connections" type="checkbox" value="all-without-connections" />
                                        </label>
                                    </p>
                                <?php endif; ?>
                                <?php if ( $field === 'subassigned' ): ?>
                                    <p>
                                        <label><?php esc_html_e( 'Filter for subassigned OR Assigned To', 'disciple_tools' ) ?>
                                            <input id="combine_subassigned" type="checkbox" value="combine_subassigned" />
                                        </label>
                                    </p>
                                <?php endif;?>
                            </div>

                        <?php else : ?>
                            <div class="tabs-panel <?php if ( $index === 0 ){ echo 'is-active'; } ?>"" id="<?php echo esc_html( $field ) ?>">
                                <div class="section-header"><?php echo esc_html( $field === 'post_date' ? __( 'Creation Date', 'disciple_tools' ) : $field_options[$field]['name'] ?? $field ) ?></div>
                                <div id="<?php echo esc_html( $field ) ?>-options">
                                    <?php if ( isset( $field_options[$field] ) && $field_options[$field]['type'] == 'key_select' ) :
                                        if ( !isset( $field_options[$field]['default']['none'] ) ) :?>
                                            <div class="key_select_options">
                                                <label style="cursor: pointer">
                                                    <input autocomplete="off" type="checkbox" data-field="<?php echo esc_html( $field ) ?>"
                                                           value="none"> <?php echo esc_html__( 'None Set', 'disciple_tools' ); ?>
                                                </label>
                                            </div>
                                        <?php endif;
                                        foreach ( $field_options[$field]['default'] as $option_key => $option_value ) :
                                            $label = $option_value['label'] ?? '';
                                            if ( empty( $label ) && ( $option_key === '' || $option_key === 'none' ) ){
                                                $label = esc_html__( 'None Set', 'disciple_tools' );
                                            }
                                            ?>
                                            <div class="key_select_options">
                                                <label style="cursor: pointer">
                                                    <input autocomplete="off" type="checkbox" data-field="<?php echo esc_html( $field ) ?>"
                                                           value="<?php echo esc_html( $option_key ) ?>"> <?php echo esc_html( $label ) ?>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php elseif ( isset( $field_options[$field] ) && $field_options[$field]['type'] == 'boolean' ) : ?>
                                        <div class="boolean_options">
                                            <label style="cursor: pointer">
                                                <input autocomplete="off" type="checkbox" data-field="<?php echo esc_html( $field ) ?>"
                                                       data-label="<?php esc_html_e( 'No', 'disciple_tools' ) ?>"
                                                       value="0"> <?php esc_html_e( 'No', 'disciple_tools' ) ?>
                                            </label>
                                        </div>
                                        <div class="boolean_options">
                                            <label style="cursor: pointer">
                                                <input autocomplete="off" type="checkbox" data-field="<?php echo esc_html( $field ) ?>"
                                                       data-label="<?php esc_html_e( 'Yes', 'disciple_tools' ) ?>"
                                                       value="1"> <?php esc_html_e( 'Yes', 'disciple_tools' ) ?>
                                            </label>
                                        </div>
                                    <?php elseif ( isset( $field_options[$field] ) && in_array( $field_options[$field]['type'], [ 'date', 'datetime' ] ) ) : ?>
                                        <strong><?php echo esc_html_x( 'Range Start', 'The start date of a date range', 'disciple_tools' ) ?></strong>
                                        <button class="clear-date-picker" style="color:firebrick"
                                                data-for="<?php echo esc_html( $field ) ?>_start">
                                            <?php echo esc_html_x( 'Clear', 'Clear/empty input', 'disciple_tools' ) ?></button>
                                        <input id="<?php echo esc_html( $field ) ?>_start"
                                               autocomplete="off"
                                               type="text" data-date-format='yy-mm-dd'
                                               class="dt_date_picker" data-delimit="start"
                                               data-field="<?php echo esc_html( $field ) ?>">
                                        <br>
                                        <strong><?php echo esc_html_x( 'Range End', 'The end date of a date range', 'disciple_tools' ) ?></strong>
                                        <button class="clear-date-picker"
                                                style="color:firebrick"
                                                data-for="<?php echo esc_html( $field ) ?>_end">
                                            <?php echo esc_html_x( 'Clear', 'Clear/empty input', 'disciple_tools' ) ?></button>
                                        <input id="<?php echo esc_html( $field ) ?>_end"
                                               autocomplete="off" type="text"
                                               data-date-format='yy-mm-dd'
                                               class="dt_date_picker" data-delimit="end"
                                               data-field="<?php echo esc_html( $field ) ?>">
                                    <?php elseif ( isset( $field_options[$field] ) && in_array( $field_options[$field]['type'], [ 'text', 'communication_channel' ] ) ) : ?>
                                        <input id="<?php echo esc_html( $field ) ?>_text_comms_filter"
                                               type="text"
                                               class="text-comms-filter-input"
                                               data-field="<?php echo esc_html( $field ) ?>"
                                               placeholder="<?php echo esc_html_x( 'Filter By Value', 'The value to be searched for', 'disciple_tools' ) ?>" />

                                        <p>
                                            <label>
                                                <input name="filter_by_text_comms_option" class="filter-by-text-comms-option" type="radio" value="all-with-filtered-value" data-field="<?php echo esc_html( $field ) ?>" />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s with filtered value in %2$s', 'All Contacts with filtered value in Emails', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                            <label>
                                                <input name="filter_by_text_comms_option" class="filter-by-text-comms-option" type="radio" value="all-without-filtered-value" data-field="<?php echo esc_html( $field ) ?>" />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s without filtered value in %2$s', 'All Contacts without filtered value in Emails', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                            <label>
                                                <input name="filter_by_text_comms_option" class="filter-by-text-comms-option" type="radio" value="all-with-set-value" data-field="<?php echo esc_html( $field ) ?>" />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s with any value in %2$s', 'All Contacts with any value in field', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                            <label>
                                                <input name="filter_by_text_comms_option" class="filter-by-text-comms-option" type="radio" value="all-without-set-value" data-field="<?php echo esc_html( $field ) ?>" />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s with no value in %2$s', 'All Contacts with no value in field', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                        </p>
                                    <?php elseif ( isset( $field_options[$field] ) && $field_options[$field]['type'] === 'file_upload' ) : ?>
                                        <p>
                                            <label>
                                                <input
                                                    name="filter_by_file_upload_option_<?php echo esc_attr( $field ) ?>"
                                                    class="filter-by-file-upload-option"
                                                    type="radio"
                                                    value="all-with-files"
                                                    data-field="<?php echo esc_html( $field ) ?>"
                                                />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s with files in %2$s', 'All Contacts with files in Documents', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                            <label>
                                                <input
                                                    name="filter_by_file_upload_option_<?php echo esc_attr( $field ) ?>"
                                                    class="filter-by-file-upload-option"
                                                    type="radio"
                                                    value="all-without-files"
                                                    data-field="<?php echo esc_html( $field ) ?>"
                                                />
                                                <?php echo esc_html( sprintf( _x( 'All %1$s without files in %2$s', 'All Contacts without files in Documents', 'disciple_tools' ), $post_settings['label_plural'], $field_options[$field]['name'] ) ) ?>
                                            </label>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="grid-x grid-padding-x">
            <div class="cell small-4 filter-modal-left">
                <button class="button button-cancel" data-close aria-label="Close reveal" type="button">
                    <?php esc_html_e( 'Cancel', 'disciple_tools' )?>
                </button>
            </div>
            <div class="cell small-8 filter-modal-right confirm-buttons">

                <div class="grid-x grid-padding-x">
                    <div class="cell small-7 filter-modal-right">
                        <input type="search" id="new-filter-name"
                               placeholder="<?php esc_html_e( 'Filter Name', 'disciple_tools' ) ?>" />
                    </div>
                    <div class="cell small-5 filter-modal-right">
                        <button style="display: inline-block;" class="button loader confirm-filter-records"
                                type="button" id="confirm-filter-records" data-close>
                            <?php esc_html_e( 'Filter Records', 'disciple_tools' ) ?>
                        </button>
                        <button class="button loader confirm-filter-records" type="button" id="save-filter-edits"
                                data-close style="display: none;">
                            <?php esc_html_e( 'Save', 'disciple_tools' ) ?>
                        </button>
                    </div>
                </div>

            </div>
        </div>
        <button class="close-button" data-close aria-label="<?php esc_html_e( 'Close', 'disciple_tools' ); ?>" type="button">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>

    <?php get_template_part( 'dt-assets/parts/modals/modal', 'filters' ); ?>

    <?php
    get_footer();
} )();
